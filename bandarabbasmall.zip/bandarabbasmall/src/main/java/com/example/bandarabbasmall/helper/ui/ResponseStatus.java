package com.example.bandarabbasmall.helper.ui;

public enum ResponseStatus {
    SUCCESS,
    FAILED,
    EXCEPTION
}
