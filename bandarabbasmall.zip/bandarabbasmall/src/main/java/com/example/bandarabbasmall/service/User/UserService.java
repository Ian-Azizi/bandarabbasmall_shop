package com.example.bandarabbasmall.service.User;

import com.example.bandarabbasmall.entites.Useres.User;
import com.example.bandarabbasmall.helper.Exception.DataNotFoundException;
import com.example.bandarabbasmall.repositores.Useres.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;


@Service

public class UserService {
    @Autowired
    private UserRepository repository;
    public User getAllById(long id) {
        Optional<User> data = repository.findAllById(id);
        if (data.isPresent()) return data.get();
        return null;
    }
    public User getAll(String shopId) {
        return (User) repository.findAllByShopId(shopId);
    }
    public User add(User data){
        return repository.save(data);
    }
    public User upData(User data){
        User oldData = getAllById(data.getId());
        if (oldData==null){
            throw new DataNotFoundException("data with id"+data.getId()+"not found");
        }
        oldData.setUserName(data.getUserName());
        oldData.setPassword(data.getPassword());
        oldData.setShopName(data.getShopName());
        oldData.setToken(data.getToken());
        oldData.setFistName(data.getFistName());
        oldData.setLastName(data.getLastName());
        return repository.save(oldData);
    }
    public boolean delete(long id){
        User oldData = getAllById(id);
        if (oldData==null){
            throw new DataNotFoundException("data with id"+id+"not found");
        }
        repository.deleteById(id);
        return true;
    }

}
