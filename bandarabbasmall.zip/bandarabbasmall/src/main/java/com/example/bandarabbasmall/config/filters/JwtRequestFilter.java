package com.example.bandarabbasmall.config.filters;

import com.example.bandarabbasmall.config.JwtTokenUtil;
import com.example.bandarabbasmall.helper.Exception.JwtTokenException;
import com.example.bandarabbasmall.service.User.UserService;
import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class JwtRequestFilter {
    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private UserService Service;

    private List<String> excludeUrls;
    private List<String> excludeContainsUrls;


    public void init(FilterConfig filterConfig) throws ServletException {
//        excludeUrls = new ArrayList<>();
//        excludeContainsUrls = new ArrayList<>();
//        excludeContainsUrls.add("/api/utils/upload/files/");
//        excludeContainsUrls.add("/api/blog/info/");
//        excludeContainsUrls.add("/api/product/getAll/");
//        excludeContainsUrls.add("/api/product/info/");
//        excludeUrls.add("/api/user/login");
//        excludeUrls.add("/api/color/");
//        excludeUrls.add("/api/nav/");
//        excludeUrls.add("/api/slider/");
//        excludeUrls.add("/api/product/newProducts");
//        excludeUrls.add("/api/product/popularProducts");
//        excludeUrls.add("/api/content/getAllData");
//        excludeUrls.add("/api/blog/getAllData");
//        excludeUrls.add("/api/productCategory");
//        excludeUrls.add("/api/payment/");
//        excludeUrls.add("/api/invoice/find");
//        excludeUrls.add("/api/user/getUserInfo");
        excludeUrls.add("user/signin");
    }


    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        try {

            String url = ((HttpServletRequest) request).getRequestURI().toLowerCase();
            if (excludeUrls.stream().anyMatch(x -> url.equals(x.toLowerCase())) ||
                    excludeContainsUrls.stream().anyMatch(x -> url.startsWith(x.toLowerCase()))) {
                chain.doFilter(request, response);
                return;
            }

            String requestTokenHeader = ((HttpServletRequest) request).getHeader("Authorization");
            if (requestTokenHeader == null || !requestTokenHeader.startsWith("Bearer "))
                throw new JwtTokenException("request token header does not set");

            String token = requestTokenHeader.substring(7);
            String username = jwtTokenUtil.getUsernameFromToken(token);

            if (username == null) {
                throw new JwtTokenException("username can not resolve");
            }

            chain.doFilter(request, response);
        } catch (JwtTokenException ex) {
            ((HttpServletResponse) response).sendError(HttpServletResponse.SC_UNAUTHORIZED, "Unauthorized");
        } catch (Exception ex) {
            ((HttpServletResponse) response).sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, ex.getMessage());
        }
    }
}
