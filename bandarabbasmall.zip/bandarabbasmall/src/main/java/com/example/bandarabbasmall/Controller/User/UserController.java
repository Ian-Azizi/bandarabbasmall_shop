package com.example.bandarabbasmall.Controller.User;


import com.example.bandarabbasmall.entites.Useres.User;
import com.example.bandarabbasmall.helper.ui.ResponseStatus;
import com.example.bandarabbasmall.helper.ui.ServiceResponse;
import com.example.bandarabbasmall.repositores.Useres.UserRepository;
import com.example.bandarabbasmall.service.User.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class UserController {
    @Autowired
    private UserService service;
    @Autowired
    private UserRepository repository;

    @GetMapping("/user/get")
    List<User> all() {
        return repository.findAll();
    }

    @PostMapping("/user/post")
    public ServiceResponse<User> addUser(@RequestBody User Date) {
        try {
            User adding = service.add(Date);
            return new ServiceResponse<User>(ResponseStatus.SUCCESS, adding);
        } catch (Exception e) {
            return new ServiceResponse<User>(e);
        }
//        return new ServiceResponse<User>(ResponseStatus.SUCCESS, Date);

    }
}
