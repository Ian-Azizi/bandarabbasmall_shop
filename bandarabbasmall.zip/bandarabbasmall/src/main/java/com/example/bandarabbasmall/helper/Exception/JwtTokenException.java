package com.example.bandarabbasmall.helper.Exception;

public class JwtTokenException extends Throwable {
    public JwtTokenException(String message) {
        super(message);
    }
}
