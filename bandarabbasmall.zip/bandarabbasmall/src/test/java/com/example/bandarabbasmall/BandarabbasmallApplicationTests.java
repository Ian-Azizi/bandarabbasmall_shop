package com.example.bandarabbasmall;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BandarabbasmallApplicationTests {

	@Test
	void contextLoads() {
	}

}
